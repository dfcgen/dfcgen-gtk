/********************************* -*- C -*- *********************************
 * Copyright (C) 2012 Ralf Hoppe <ralf.hoppe@ieee.org>
 * Version: $Id: export.c 184 2012-05-19 16:01:59Z ralf $
 *
 * DFCGEN-GTK exported coefficients
 *
 *****************************************************************************/

#ifndef DFCGEN
#define DFCGEN

dfcoeff_t numerator[$PRJ:FILTER:NUM:DEGREE$ + 1] =
{
    $PRJ:FILTER:NUM:COEFF$, /* z^{$PRJ:FILTER:NUM:EXPONENT$} */
};


dfcoeff_t denominator[$PRJ:FILTER:DEN:DEGREE$ + 1] =
{
    $PRJ:FILTER:DEN:COEFF$, /* z^{$PRJ:FILTER:DEN:EXPONENT$} */
};


#endif /* DFCGEN */
