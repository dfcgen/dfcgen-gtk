/********************* -*- mode: C; coding: utf-8 -*- *************************/
/**
 * \file
 *           Interface to dialog functions of \e File menu.
 *
 * \author   Copyright (c) 2006 Ralf Hoppe <ralf.hoppe@ieee.org>
 * \version  $Header: /home/cvs/dfcgen-gtk/include/fileDlg.h,v 1.1.1.1 2006/09/11 15:52:21 ralf Exp $
 *
 *
 * History:
 * $Log: fileDlg.h,v $
 * Revision 1.1.1.1  2006/09/11 15:52:21  ralf
 * Initial CVS import
 *
 *
 *
 ******************************************************************************/


#ifndef FILEDLG_H
#define FILEDLG_H


/* INCLUDE FILES **************************************************************/

#include "gui.h"


#ifdef  __cplusplus
extern "C" {
#endif


/* GLOBAL TYPE DECLARATIONS ***************************************************/


/* GLOBAL CONSTANT DECLARATIONS ***********************************************/


/* GLOBAL VARIABLE DECLARATIONS ***********************************************/


/* GLOBAL MACRO DEFINITIONS ***************************************************/


/* EXPORTED FUNCTIONS *********************************************************/


/* FUNCTION *******************************************************************/
/** \e Activate event callback emitted when the \e New menuitem is selected
 *  from \e File menu.
 *
 *  \param menuitem     The menu item object which received the signal (New).
 *  \param user_data    User data set when the signal handler was connected (unused).
 *
 ******************************************************************************/
    void fileDlgNewActivate (GtkMenuItem* menuitem, gpointer user_data);


/* FUNCTION *******************************************************************/
/** \e Activate event callback emitted when the \e Open menuitem is selected
 *  from \e File menu.
 *
 *  \param srcWidget    \e File \e Open widget (GtkMenuItem on event \e activate
 *                      or GtkToolButton on event \e clicked), which causes this
 *                      call.
 *  \param user_data    User data set when the signal handler was connected (unused).
 *
 ******************************************************************************/
    void fileDlgOpenActivate (GtkWidget* srcWidget, gpointer user_data);


/* FUNCTION *******************************************************************/
/** \e Activate event callback emitted when the \e Save menuitem is selected
 *  from \e File menu.
 *
 *  \param srcWidget    \e File \e Save widget (GtkMenuItem on event \e activate
 *                      or GtkToolButton on event \e clicked), which causes this
 *                      call.
 *  \param user_data    User data set when the signal handler was connected (unused).
 *
 ******************************************************************************/
    void fileDlgSaveActivate (GtkWidget* srcWidget, gpointer user_data);



/* FUNCTION *******************************************************************/
/** \e Activate event callback emitted when the \e Save \e As menuitem is
 *  selected from \e File menu.
 *
 *  \param srcWidget    \e File \e Save \e As widget (GtkMenuItem on event
 *                      \e activate or GtkToolButton on event \e clicked),
 *                      which causes this call.
 *  \param user_data    User data set when the signal handler was connected (unused).
 *
 ******************************************************************************/
    void fileDlgSaveAsActivate (GtkWidget* srcWidget, gpointer user_data);



/* FUNCTION *******************************************************************/
/** \e Activate event callback emitted when the \e Print menuitem is selected
 *  from \e File menu.
 *
 *  \param menuitem     The menu item object which received the signal (Print).
 *  \param user_data    User data set when the signal handler was connected (unused).
 *
 *  \todo               Parametrization of gtk_print_operation_set_print_settings()
 *                      and gtk_print_operation_set_default_page_setup().
 ******************************************************************************/
    void fileDlgPrintActivate (GtkMenuItem* menuitem, gpointer user_data);


#ifdef  __cplusplus
}
#endif


#endif /* FILEDLG_H */


/******************************************************************************/
/* END OF FILE                                                                */
/******************************************************************************/
